### Project 1 README file
The starting point of this project is the home page.
this website contains some small hobbies that i have for myself and some information about it.